# Task tools
# This module contains a set of functions used for execution of any tasks
# List of functions implemented:
#   1) pol_cell: the policy (recurrent) neural network main computation
#   2) val_cell: the value (recurrent) neural network main computation
#   3) action_choice: Chooses an action given the probabilities of each action


import numpy as np
import tensorflow as tf
import math
from parameters import *
import pdb


def pol_cell(pol_u, pol_x, **kwargs):
    '''
    Policy network main computation
    Calculates the next hidden state activity given current input (u)
    and hidden state activity in the previous step (h)
    Inputs:
        u: Input at time t
        x: hidden state activity at time t-1, input currents

    Outputs:
        next_x: hidden state activity at time t, input currents
        next_r: firing rate of hidden units at time t
        other_params: Other parameters if relevant,
            e.g. update and reset gate values for GRU units
    '''

    # Calculate firing rate (r) at time t-1 from current (x) at time t-1
    pol_r = tf.nn.relu(pol_x)

    # Get the recurrnet and input weights
    with tf.variable_scope('pol_rnn_cell', reuse=True):
            pol_W_in = tf.get_variable('pol_W_in', dtype=tf.float64)
            pol_W_rnn = tf.get_variable('pol_W_rnn', dtype=tf.float64)
            pol_b_rnn = tf.get_variable('pol_b_rnn', dtype=tf.float64)

    ####### GRU networks #######
    if par['pol_unit_type'] == 'GRU':
        # Implementation of equations 34, 35, 36 and 37 from Song et al., 2017
        # 1) Get the weights to calculate update and reset parameters
        # Weights for calculating update gate values
        with tf.variable_scope('pol_update', reuse=True):
            pol_W_in_update = tf.get_variable('pol_W_in_update', dtype=tf.float64)
            pol_W_rnn_update = tf.get_variable('pol_W_rnn_update', dtype=tf.float64)
            pol_b_rnn_update = tf.get_variable('pol_b_rnn_update', dtype=tf.float64)
        # Weights for calculating reset gate values
        with tf.variable_scope('pol_reset', reuse=True):
            pol_W_in_reset = tf.get_variable('pol_W_in_reset', dtype=tf.float64)
            pol_W_rnn_reset = tf.get_variable('pol_W_rnn_reset', dtype=tf.float64)
            pol_b_rnn_reset = tf.get_variable('pol_b_rnn_reset', dtype=tf.float64)
        # 2) Update gate values (lambda), equation (34), Song et al., 2017
        pol_update_vals = tf.sigmoid(tf.matmul(pol_W_in_update, pol_u)
                            + tf.matmul(pol_W_rnn_update, pol_r)
                            + pol_b_rnn_update)
        # 3) Update reset values (gamma), equation (35), Song et al., 2017
        pol_reset_vals = tf.sigmoid(tf.matmul(pol_W_in_reset, pol_u)
                            + tf.matmul(pol_W_rnn_reset, pol_r)
                            + pol_b_rnn_reset)
        # 4) Calculate hidden state activity (x and r) at the next time step,
        # Equations (36) and (37), Song et al. 2017
        # Input currents (x)

        # Recurrent noise
        pol_rec_noise = tf.random_normal([par['pol_n_hidden'], par['batch_train_size']], 0, par['noise_rnn'], dtype=tf.float64)
        # Caclulate next x
        pol_next_x = tf.multiply((1-par['alpha_neuron']*pol_update_vals),pol_r) + \
                 tf.multiply(par['alpha_neuron']*pol_update_vals, \
                             tf.matmul(pol_W_rnn, tf.multiply(pol_reset_vals,pol_r)) + tf.matmul(pol_W_in,pol_u) + pol_b_rnn + pol_rec_noise)
        # Firing rates (r)
        pol_next_r = tf.nn.relu(pol_next_x)
        pol_other_params = {'update_vals':      pol_update_vals,
                        'reset_vals':       pol_reset_vals}


    ####### Linear networks #######
    if par['pol_unit_type'] == 'Linear':
        # Implementation of a Linear traditional recurrent unit (without the GRU)
        # Calculate hidden state activity (x and r) at the next time step
        # Equations 7, 8 and 9 form Song et al., 2016 (traditional RNNs)
        # Recurrent noise
        pol_rec_noise = tf.random_normal([par['pol_n_hidden'], par['batch_train_size']], 0, par['noise_rnn'], dtype=tf.float64)
        # Caclulate next x
        pol_next_x = (1-par['alpha_neuron'])*pol_r + \
                    par['alpha_neuron']*(tf.matmul(pol_W_rnn,pol_r) + tf.matmul(pol_W_in,pol_u) + pol_b_rnn) + pol_rec_noise
        # Firing rates (r)
        pol_next_r = tf.nn.relu(pol_next_x)
        pol_other_params = {}   # No other params for a linear unit


    ####### Cells with STSP implemented #######
    """
    For more information on short term synaptic plasticity see:
    http://www.scholarpedia.org/article/Short-term_synaptic_plasticity
    """
    if par['pol_unit_type'] == 'STSP':
        # Get initial conditions for synpatic utilization (syn_u) and synaptic available resources (syn_x)
        # The syn_x and syn_u variables correspond to x and u variables in equation (1) of the article linked above
        for key, value in kwargs.items():
            if key=='pol_syn_u_init':
                syn_u = value
            if key=='pol_syn_x_init':
                syn_x = value
        # Unpack synaptic plasticity parameters
        U = par['pol_syn_par']['U']
        alpha_std = par['pol_syn_par']['alpha_std']
        alpha_stf = par['pol_syn_par']['alpha_stf']
        # implement both synaptic short term facilitation and depression
        syn_x += alpha_std*(1-syn_x) - par['dt']/1000*syn_u*syn_x*pol_x
        syn_u += alpha_stf*(U-syn_u) + par['dt']/1000*U*(1-syn_u)*pol_x
        syn_x = tf.minimum(np.float64(1), tf.nn.relu(syn_x))
        syn_u = tf.minimum(np.float64(1), tf.nn.relu(syn_u))
        # Calculate post synaptic current with synaptic facilitation and depression
        pol_x_post = syn_u*syn_x*pol_x

        # Calculate
        pol_rec_noise = tf.random_normal([par['pol_n_hidden'], par['batch_train_size']], 0, par['noise_rnn'], dtype=tf.float64)
        # Caclulate next x
        pol_next_x = (1-par['alpha_neuron'])*pol_x_post + \
                    par['alpha_neuron']*(tf.matmul(pol_W_rnn,pol_r) + tf.matmul(pol_W_in,pol_u) + pol_b_rnn) + pol_rec_noise
        # Firing rates (r)
        pol_next_r = tf.nn.relu(pol_next_x)
        pol_other_params = {'syn_u':    syn_u,
                            'syn_x':    syn_x}   # No other params for a linear unit

    return pol_next_x, pol_next_r, pol_other_params

def val_cell(val_u, val_x, **kwargs):
    '''
    Value network main computation
    Calculates the next hidden state activity given current input (u)
    and hidden state activity in the previous step (h)
    Inputs:
        u: Input at time t
        x: hidden state activity at time t-1, input currents

    Outputs:
        next_x: hidden state activity at time t, input currents
        next_r: firing rate of hidden units at time t
        other_params: Other parameters if relevant,
            e.g. update and reset gate values for GRU units
    '''

    # Calculate firing rate (r) at time t-1 from current (x) at time t-1
    val_r = tf.nn.relu(val_x)

    # Get the recurrnet and input weights
    with tf.variable_scope('val_rnn_cell', reuse=True):
            val_W_in = tf.get_variable('val_W_in', dtype=tf.float64)
            val_W_rnn = tf.get_variable('val_W_rnn', dtype=tf.float64)
            val_b_rnn = tf.get_variable('val_b_rnn', dtype=tf.float64)

    ####### GRU networks #######
    if par['val_unit_type'] == 'GRU':
        # Implementation of equations 34, 35, 36 and 37 from Song et al., 2017
        # 1) Define the sigmoid function
        # def sigmoid(x):
        #    return 1 / (1 + math.exp(-x))
        # 2) Get the weights to calculate update and reset parameters
        # Weights for calculating update gate values
        with tf.variable_scope('val_update', reuse=True):
            val_W_in_update = tf.get_variable('val_W_in_update', dtype=tf.float64)
            val_W_rnn_update = tf.get_variable('val_W_rnn_update', dtype=tf.float64)
            val_b_rnn_update = tf.get_variable('val_b_rnn_update', dtype=tf.float64)
        # Weights for calculating reset gate values
        with tf.variable_scope('val_reset', reuse=True):
            val_W_in_reset = tf.get_variable('val_W_in_reset', dtype=tf.float64)
            val_W_rnn_reset = tf.get_variable('val_W_rnn_reset', dtype=tf.float64)
            val_b_rnn_reset = tf.get_variable('val_b_rnn_reset', dtype=tf.float64)
        # 3) Update gate values (lambda), equation (34), Song et al., 2017
        val_update_vals = tf.sigmoid(tf.matmul(val_W_in_update, val_u)
                            + tf.matmul(val_W_rnn_update, val_r)
                            + val_b_rnn_update)
        # 4) Update reset values (gamma), equation (35), Song et al., 2017
        val_reset_vals = tf.sigmoid(tf.matmul(val_W_in_reset, val_u)
                            + tf.matmul(val_W_rnn_reset, val_r)
                            + val_b_rnn_reset)
        # 5) Calculate hidden state activity (x and r) at the next time step,
        # Equations (36) and (37), Song et al. 2017
        # Input currents (x)

        # Recurrent noise
        val_rec_noise = tf.random_normal([par['n_hidden'], par['batch_train_size']], 0, par['noise_rnn'], dtype=tf.float64)
        # Caclulate next x
        val_next_x = tf.multiply((1-par['alpha_neuron']*val_update_vals),val_x) + \
                 tf.multiply(par['alpha_neuron']*val_update_vals, \
                             tf.matmul(val_W_rnn, tf.multiply(val_reset_vals,val_r)) + tf.matmul(val_W_in,val_u) + val_b_rnn + val_rec_noise)
        # Firing rates (r)
        val_next_r = tf.nn.relu(val_next_x)
        val_other_params = {'update_vals':      val_update_vals,
                        'reset_vals':       val_reset_vals}


    ####### Linear networks #######
    if par['val_unit_type'] == 'Linear':
        # Implementation of a Linear traditional recurrent unit (without the GRU)
        # Calculate hidden state activity (x and r) at the next time step
        # Equations 7, 8 and 9 form Song et al., 2016 (traditional RNNs)
        # Recurrent noise
        val_rec_noise = tf.random_normal([par['val_n_hidden'], par['batch_train_size']], 0, par['noise_rnn'], dtype=tf.float64)
        # Caclulate next x
        val_next_x = (1-par['alpha_neuron'])*val_r + \
                    par['alpha_neuron']*(tf.matmul(val_W_rnn,val_r) + tf.matmul(val_W_in,val_u) + val_b_rnn) + val_rec_noise
        # Firing rates (r)
        val_next_r = tf.nn.relu(val_next_x)
        val_other_params = {}   # No other params for a linear unit


    ####### Cells with STSP implemented #######
    """
    For more information on short term synaptic plasticity see:
    http://www.scholarpedia.org/article/Short-term_synaptic_plasticity
    """
    if par['val_unit_type'] == 'STSP':
        # Get initial conditions for synpatic utilization (syn_u) and synaptic available resources (syn_x)
        # The syn_x and syn_u variables correspond to x and u variables in equation (1) of the article linked above
        for key, value in kwargs.items():
            if key=='val_syn_u_init':
                syn_u = value
            if key=='val_syn_x_init':
                syn_x = value
        # Unpack synaptic plasticity parameters
        U = par['val_syn_par']['U']
        alpha_std = par['val_syn_par']['alpha_std']
        alpha_stf = par['val_syn_par']['alpha_stf']
        # implement both synaptic short term facilitation and depression
        syn_x += alpha_std*(1-syn_x) - par['dt']/1000*syn_u*syn_x*val_x
        syn_u += alpha_stf*(U-syn_u) + par['dt']/1000*U*(1-syn_u)*val_x
        syn_x = tf.minimum(np.float64(1), tf.nn.relu(syn_x))
        syn_u = tf.minimum(np.float64(1), tf.nn.relu(syn_u))
        # Calculate post synaptic current with synaptic facilitation and depression
        val_x_post = syn_u*syn_x*val_x

        # Calculate
        val_rec_noise = tf.random_normal([par['val_n_hidden'], par['batch_train_size']], 0, par['noise_rnn'], dtype=tf.float64)
        # Caclulate next x
        val_next_x = (1-par['alpha_neuron'])*val_x_post + \
                    par['alpha_neuron']*(tf.matmul(val_W_rnn,val_r) + tf.matmul(val_W_in,val_u) + val_b_rnn) + val_rec_noise
        # Firing rates (r)
        val_next_r = tf.nn.relu(val_next_x)
        val_other_params = {'syn_u':    syn_u,
                            'syn_x':    syn_x}

    return val_next_x, val_next_r, val_other_params
