import numpy as np
import tensorflow as tf
import os

print("--> Loading parameters...")

"""
Independent parameters
"""

par = {
    # My parameters
    'pol_unit_type'             : 'Linear', # Policy network unit type: Type of single hidden layer unit
    'val_unit_type'             : 'Linear', # Value network unit type: Type of single hidden layer unit
    'num_input'             : 36,
    'discount_time_constant': 10000,    # Time constant for discount reward in ms (per Song et al., 2017)
    'weight_cost'           : 0,      # Weight of L2 norm of policy network recurrent weights to encourage low connection densities (added by Pantea)
    'num_receptive_fields'  : 1,
    'num_motion_dirs'       : 8,
    #'num_motion_tuned'      : 36,
    #'num_fix_tuned'         : 1,
    'num_rule_tuned'        : 0,
    'num_rules'             : 1,
    'tuning_height'         : 4,
    'kappa'                 : 2,
    'trial_type'            : 'DMC',
    'variable_delay_max'    : 100,
    'var_delay'             : False,
    'decoding_test_mode'    : True,
    'catch_trial_pct'       : 0,
    'rotation_match'        : 0,

    # Setup parameters
    'save_dir'              : './savedir/',
    'debug_model'           : False,
    'load_previous_model'   : False,
    'analyze_model'         : True,

    # Network configuration
    'synapse_config'        : None, # Full is 'std_stf'
    'exc_inh_prop'          : 1.,       # Literature 0.8, for EI off 1
    'var_delay'             : False,

    # Network shape
    'num_motion_tuned'      : 36,
    'num_fix_tuned'         : 0,
    'num_rule_tuned'        : 12,
    'n_hidden'              : 100,
    'pol_n_hidden'          : 100,
    'val_n_hidden'          : 100,
    'pol_num_input'         : 36,
    'pol_n_output'          : 3,
    'n_output'              : 3,

    # Timings and rates
    'dt'                    : 10,
    'learning_rate'         : 1e-2,
    'membrane_time_constant': 100,
    'connection_prob'       : 1,         # Usually 1


    # Variance values
    'clip_max_grad_val'     : 1,
    'input_mean'            : 0.0,
    'noise_in_sd'           : 0.0002*0,
    'noise_rnn_sd'          : 0.0002*0,

    # Tuning function data
    'num_motion_dirs'       : 8,
    'tuning_height'         : 4,        # magnitutde scaling factor for von Mises
    'kappa'                 : 2,        # concentration scaling factor for von Mises

    # Cost parameters
    'spike_cost'            : 1e-7,
    'wiring_cost'           : 0.,

    # Synaptic plasticity specs
    'tau_fast'              : 200,
    'tau_slow'              : 1500,
    'U_stf'                 : 0.15,
    'U_std'                 : 0.45,

    # Training specs
    'batch_train_size'      : 1024,
    'num_iterations'        : 20000,
    'iters_between_outputs' : 25,

    # Task specs
    #'trial_type'            : 'DMS', # allowable types: DMS, DMRS45, DMRS90, DMRS180, DMC, DMS+DMRS, ABBA, ABCA, dualDMS	# Commented by Pantea, so it can be an input to the program
    'rotation_match'        : 0,  # angular difference between matching sample and test
    'dead_time'             : 200,
    'fix_time'              : 200,
    'sample_time'           : 400,
    'delay_time'            : 100,
    'test_time'             : 400,
    'variable_delay_max'    : 300,
    'mask_duration'         : 50,  # duration of traing mask after test onset
    'catch_trial_pct'       : 0.0,
    'num_receptive_fields'  : 1,
    'num_rules'             : 1, # this will be two for the DMS+DMRS task

    # Save paths
    'save_fn'               : 'model_results.pkl',

    # Analysis
    'svm_normalize'         : True,
    'decoding_reps'         : 100,
    'simulation_reps'       : 100,
    'decode_test'           : False,
    'decode_rule'           : True,
    'decode_sample_vs_test' : False,
    'suppress_analysis'     : False,
    'analyze_tuning'        : False,

}


"""
Dependent parameters
"""

def update_parameters(updates):
    """
    Takes a list of strings and values for updating parameters in the parameter dictionary
    Example: updates = [(key, val), (key, val)]
    """
    print('Updating parameters...')
    for key, val in updates.items():
        par[key] = val
        #print('Updating ', key)

    update_trial_params()
    update_dependencies()

def update_trial_params():

    """
    Update all the trial parameters given trial_type
    """

    par['num_rules'] = 1
    par['num_rule_tuned'] = 0
    par['ABBA_delay' ] = 0

    par['rotation_match'] = 0


def update_dependencies():
    """
    Updates all parameter dependencies
    """

    # Number of input neurons
    par['n_input'] = par['num_motion_tuned'] + par['num_fix_tuned'] + par['num_rule_tuned']
    # General network shape
    par['shape'] = (par['n_input'], par['n_hidden'], par['n_output'])

    # Possible rules based on rule type values
    #par['possible_rules'] = [par['num_receptive_fields'], par['num_categorizations']]

    # If num_inh_units is set > 0, then neurons can be either excitatory or
    # inihibitory; is num_inh_units = 0, then the weights projecting from
    # a single neuron can be a mixture of excitatory or inhibitory
    if par['exc_inh_prop'] < 1:
        par['EI'] = True
    else:
        par['EI']  = False

    par['num_exc_units'] = int(np.round(par['n_hidden']*par['exc_inh_prop']))
    par['num_inh_units'] = par['n_hidden'] - par['num_exc_units']

    par['EI_list'] = np.ones(par['n_hidden'], dtype=np.float64)
    par['EI_list'][-par['num_inh_units']:] = -1.

    par['drop_mask'] = np.ones((par['n_hidden'],par['n_hidden']), dtype=np.float64)
    ind_inh = np.where(par['EI_list']==-1)[0]
    par['drop_mask'][:, ind_inh] = 0.
    par['drop_mask'][ind_inh, :] = 0.

    par['EI_matrix'] = np.diag(par['EI_list'])

    # Membrane time constant of RNN neurons
    par['alpha_neuron'] = np.float64(par['dt'])/par['membrane_time_constant']
    # The standard deviation of the Gaussian noise added to each RNN neuron
    # at each time step
    par['noise_rnn'] = np.sqrt(2*par['alpha_neuron'])*par['noise_rnn_sd']
    par['noise_in'] = np.sqrt(2/par['alpha_neuron'])*par['noise_in_sd'] # since term will be multiplied by par['alpha_neuron']


    # The time step in seconds
    par['dt_sec'] = par['dt']/1000
    # Length of each trial in ms

    par['trial_length'] = par['dead_time']+par['fix_time']+par['sample_time']+par['delay_time']+par['test_time']
    # Length of each trial in time steps
    par['num_time_steps'] = par['trial_length']//par['dt']


    ####################################################################
    ### Setting up assorted intial weights, biases, and other values ###
    ####################################################################
    par['h_init'] = 0.1*np.ones((par['n_hidden'], par['batch_train_size']), dtype=np.float64)

    par['input_to_hidden_dims'] = [par['n_hidden'], par['n_input']]
    par['hidden_to_hidden_dims'] = [par['n_hidden'], par['n_hidden']]

    ####### added by Pantea, initilizer for the weight set
    c = 0.1
    par['pol_w_in0'] = np.float64(np.random.uniform(-c,c, size = [par['pol_n_hidden'], par['pol_num_input']]))
    par['pol_w_rnn0'] = np.float64(np.random.uniform(-c,c, size = [par['pol_n_hidden'], par['pol_n_hidden']]))
    par['pol_b_rnn0'] = np.float64(np.random.uniform(-c,c, size = [par['pol_n_hidden'], 1]))
    par['pol_w_out0'] = np.float64(np.random.uniform(-c,c, size = [par['pol_n_output'], par['pol_n_hidden']]))
    par['pol_b_out0'] = np.zeros([par['pol_n_output'], 1], dtype = np.float64)
    # Value network shape
    # Reminder: Value network only has one output: expected reward (Song et al., 2017)
    # Value network gets as input activity of all the hidden units in the policy network
    # as well as agent (i.e. which decisions have zero values (not made) and which one has a value of one (made))
    par['val_num_input'] = par['pol_n_hidden'] + par['pol_n_output']   # Number of inputs to the value network
    par['val_n_hidden'] = 100  # Number of hidden units in the recurrent network
    par['val_n_output'] = 1    # Number of outputs for the value network

    # Initialize input weights for the value network
    par['val_w_in0'] = np.float64(np.random.uniform(-c,c, size = [par['val_n_hidden'], par['val_num_input']]))
    par['val_w_rnn0'] = np.float64(np.random.uniform(-c,c, size = [par['val_n_hidden'], par['val_n_hidden']]))
    par['val_b_rnn0'] = np.float64(np.random.uniform(-c,c, size = [par['val_n_hidden'], 1]))
    par['val_w_out0'] = np.float64(np.random.uniform(-c,c, size = [par['val_n_output'], par['val_n_hidden']]))
    par['val_b_out0'] = np.float64(np.random.uniform(-c,c, size = [1, 1]))
    ############ End of added by Pantea


    # Initialize input weights
    par['w_in0'] = initialize([par['n_hidden'], par['n_input']], par['connection_prob'])

    # Initialize starting recurrent weights
    # If excitatory/inhibitory neurons desired, initializes with random matrix with
    #   zeroes on the diagonal
    # If not, initializes with a diagonal matrix
    if par['EI']:
        par['w_rnn0'] = initialize([par['n_hidden'], par['n_hidden']], par['connection_prob'])

        for i in range(par['n_hidden']):
            par['w_rnn0'][i,i] = 0
        par['w_rnn_mask'] = np.ones((par['n_hidden'], par['n_hidden']), dtype=np.float64) - np.eye(par['n_hidden'])
    else:
        par['w_rnn0'] = 0.54*np.eye(par['n_hidden'])
        par['w_rnn_mask'] = np.ones((par['n_hidden'], par['n_hidden']), dtype=np.float64)

    par['b_rnn0'] = np.zeros((par['n_hidden'], 1), dtype=np.float64)

    # Effective synaptic weights are stronger when no short-term synaptic plasticity
    # is used, so the strength of the recurrent weights is reduced to compensate

    if par['synapse_config'] == None:
        par['w_rnn0'] = par['w_rnn0']/(spectral_radius(par['w_rnn0']))


    # Initialize output weights and biases
    par['w_out0'] =initialize([par['n_output'], par['n_hidden']], par['connection_prob'])
    par['b_out0'] = np.zeros((par['n_output'], 1), dtype=np.float64)
    par['b_out0'][0,0] = 0.25
    par['w_out_mask'] = np.ones((par['n_output'], par['n_hidden']), dtype=np.float64)

    if par['EI']:
        par['ind_inh'] = np.where(par['EI_list'] == -1)[0]
        par['w_out0'][:, par['ind_inh']] = 0
        par['w_out_mask'][:, par['ind_inh']] = 0

    """
    Setting up synaptic parameters
    0 = static
    1 = facilitating
    2 = depressing
    """
    par['synapse_type'] = np.zeros(par['n_hidden'], dtype=np.int8)

    # only facilitating synapses
    if par['synapse_config'] == 'stf':
        par['synapse_type'] = np.ones(par['n_hidden'], dtype=np.int8)

    # only depressing synapses
    elif par['synapse_config'] == 'std':
        par['synapse_type'] = 2*np.ones(par['n_hidden'], dtype=np.int8)

    # even numbers facilitating, odd numbers depressing
    elif par['synapse_config'] == 'std_stf':
        par['synapse_type'] = np.ones(par['n_hidden'], dtype=np.int8)
        par['ind'] = range(1,par['n_hidden'],2)
        par['synapse_type'][par['ind']] = 2

    par['alpha_stf'] = np.ones((par['n_hidden'], 1), dtype=np.float64)
    par['alpha_std'] = np.ones((par['n_hidden'], 1), dtype=np.float64)
    par['U'] = np.ones((par['n_hidden'], 1), dtype=np.float64)

    # initial synaptic values
    par['syn_x_init'] = np.zeros((par['n_hidden'], par['batch_train_size']), dtype=np.float64)
    par['syn_u_init'] = np.zeros((par['n_hidden'], par['batch_train_size']), dtype=np.float64)

    for i in range(par['n_hidden']):
        if par['synapse_type'][i] == 1:
            par['alpha_stf'][i,0] = par['dt']/par['tau_slow']
            par['alpha_std'][i,0] = par['dt']/par['tau_fast']
            par['U'][i,0] = 0.15
            par['syn_x_init'][i,:] = 1
            par['syn_u_init'][i,:] = par['U'][i,0]

        elif par['synapse_type'][i] == 2:
            par['alpha_stf'][i,0] = par['dt']/par['tau_fast']
            par['alpha_std'][i,0] = par['dt']/par['tau_slow']
            par['U'][i,0] = 0.45
            par['syn_x_init'][i,:] = 1
            par['syn_u_init'][i,:] = par['U'][i,0]

# Added by Pantea
def set_synaptic_parameters(n_hidden):

    """
    Setting up synaptic parameters for a given number of hidden units (n_hidden)
    1 = facilitating
    2 = depressing
    Output: A dictionary object containing all the necessary arrays
    """
    syn_par = {}    # Dictionary object containing all pertaining parameters
    # even numbers facilitating (i.e. 1), odd numbers depressing (i.e. 2)
    syn_par['synapse_type'] = np.ones(n_hidden, dtype=np.int8)
    syn_par['ind'] = range(1,n_hidden,2)
    syn_par['synapse_type'][syn_par['ind']] = 2

    syn_par['alpha_stf'] = np.ones((n_hidden, 1), dtype=np.float32)
    syn_par['alpha_std'] = np.ones((n_hidden, 1), dtype=np.float32)
    syn_par['U'] = np.ones((n_hidden, 1), dtype=np.float32)

    # initial synaptic values
    syn_par['syn_x_init'] = np.zeros((n_hidden, par['batch_train_size']), dtype=np.float32)
    syn_par['syn_u_init'] = np.zeros((n_hidden, par['batch_train_size']), dtype=np.float32)

    for i in range(n_hidden):
        if syn_par['synapse_type'][i] == 1:
            syn_par['alpha_stf'][i,0] = par['dt']/par['tau_slow']
            syn_par['alpha_std'][i,0] = par['dt']/par['tau_fast']
            syn_par['U'][i,0] = 0.15
            syn_par['syn_x_init'][i,:] = 1
            syn_par['syn_u_init'][i,:] = syn_par['U'][i,0]

        elif syn_par['synapse_type'][i] == 2:
            syn_par['alpha_stf'][i,0] = par['dt']/par['tau_fast']
            syn_par['alpha_std'][i,0] = par['dt']/par['tau_slow']
            syn_par['U'][i,0] = 0.45
            syn_par['syn_x_init'][i,:] = 1
            syn_par['syn_u_init'][i,:] = syn_par['U'][i,0 ]
    return syn_par


def initialize(dims, connection_prob):
    w = np.random.gamma(shape=0.25, scale=1.0, size=dims)
    #w = np.random.uniform(0,0.25, size=dims)
    w *= (np.random.rand(*dims) < connection_prob)
    return np.float64(w)


def spectral_radius(A):

    return np.max(abs(np.linalg.eigvals(A)))

update_trial_params()
update_dependencies()

print("--> Parameters successfully loaded.\n")
