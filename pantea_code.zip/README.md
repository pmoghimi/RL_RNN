# Short-term-plasticity-RNN
Short-term plasticity RNN models in Tensorflow
