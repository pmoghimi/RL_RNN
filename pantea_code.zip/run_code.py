# run_code
import Tasks.DMC
from Tasks.DMC import dmc
import matplotlib.pyplot as plt
import numpy as np
import pdb
import model
#from model import Model
import model_RL
from parameters import *

#pdb.set_trace()
"""
Reset TensorFlow before running anything
"""
tf.reset_default_graph()
par['trial_type'] = 'DMC'
A = dmc(par['batch_train_size'])
model.main(A)

#par['trial_type'] = 'DMC'
#model_RL.main()
'''
TO DO LIST:
1) Implement biological constrains on RL, i.e. Dale's law, read out from exitatory weights only, etc.
2) Implement short term plasticity, compare performance with and without short term plasticity
3) Compare RL with supervised per Nick and supervised per Wang lab (r and x separated)
4) Play with learning rates with the supervised method
5) Introduce RFs, spatial aspects, potentially Clunen stuff
6) Implement linearization and state space representation and dPCA
7) Introduce weight sparsity (i.e. add L2 norm of the recurrent weights to the cost function) for the policy network
8) Explore order of training for policy and baseline networks, Wang did baseline first, why? does it matter?
'''
