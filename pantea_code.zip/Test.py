'''
Test.py
Whenever I need to test something, I will use this script,
not used by the actual program
'''

import numpy as np
import tensorflow as tf

# Trying to figure out how append works
data  = []
# Now let's work with variables
W = tf.Variable(np.zeros((3, 1)), dtype = tf.float64)
for i in range(5):
    W = W + np.ones((3, 1))
    data.append(W)

# Define Session
sess = tf.Session()
# Initialize variables first
init = tf.global_variables_initializer()
sess.run(init)
# Now run and get values for the linear model defined above
#sess.run(mod, {x:np.arange(-3, 3, 1)}))
final_data = sess.run(data)
final_data_a = np.array(final_data)
